#version 330 core

// Interpolated values from the vertex shaders
in vec3 fsColor;

// Ouput data
out vec4 color;

uniform float alpha;

void main()
{
	color = vec4(fsColor, alpha);
}