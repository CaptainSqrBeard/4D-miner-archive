#version 330 core

// Interpolated values from the vertex shaders
in vec3 fsTUV;

// Ouput data
out vec4 color;

// Values that stay constant for the whole mesh.
uniform sampler2D texSampler;
uniform uvec2 texSize;

void main()
{
	// Output color = color of the texture at the specified UV
	color = texture(texSampler, vec2(fsTUV.x, fsTUV.y + (floor(fsTUV.z) / texSize.y)));
}