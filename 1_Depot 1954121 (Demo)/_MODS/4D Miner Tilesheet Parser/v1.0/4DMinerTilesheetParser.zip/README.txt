Made by Tr1NgleBoss
Discord tag: _-Tr1NgleBoss-_#9825
Discord ID: 450597912334958593

DESCRIPTION:

This program can split the tilesheet (tiles.png) file of 4D Miner into separate files. Additionally it can merge said files into a new tilesheet.

SCALE - the attribute that governs the textures' dimensions.
	- The minimal value is 1 (4x2 textures)
	- The value for the original file is 8 (32x16 textures)
	- You have to restart the program to change it!


STEP-BY-STEP INSTRUCTION:

1. Enter the SCALE value;
2. Choose the mode:
	- press P key for PARSE mode (split);
	- press M key for MERGE mode (merge);

PARSE mode:
3. Enter the spritesheet file path;
	- press SHIFT+RMB on the file and choose "Copy as path"
	- example: "C:\Program Files (x86)\Steam\steamapps\common\4D Miner Demo\assets\textures\tiles.png"
4. The program will save the split files into a folder named after the original tilesheet, located in the same folder as the chosen file.

MERGE mode:
3. Enter the path to the folder containing the tiles;
	- example: "C:\Program Files (x86)\Steam\steamapps\common\4D Miner Demo\assets\textures\tiles"
4. The program will save the merged tilesheet called tiles-output.png in the chosen folder.