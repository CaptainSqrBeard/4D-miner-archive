import os

chunkSize = 8
chunkHeight = 128

class editableChunk:

    def __init__(s):

        s.data = {}

    def setBlock(s, x, y, z, w, block):

        s.data[(x,y,z,w)] = block
    
    def toBin(s):

        d = s.data
        
        output = b""

        lastBlock = 0

        count = 0
        
        for x in range(chunkSize):
            for y in range(chunkHeight):
                for z in range(chunkSize):
                    for w in range(chunkSize):

                        coords = (x,y,z,w)
                        currentBlock = 0
                        if coords in d:
                            currentBlock = d[coords]

                        if currentBlock != lastBlock or count >= 255:

                            output = output + lastBlock.to_bytes(1, "big") + count.to_bytes(1, "big")
                            
                            lastBlock = currentBlock
                            count = 0

                        count += 1

        count -= 1
        output = output + lastBlock.to_bytes(1, "big") + count.to_bytes(1, "big")

        return output



class editableWorld:

    def __init__(s):

        s.data = {}
    
    def setBlock(s, x, y, z, w, block):

        s.data[(x,y,z,w)] = block

    def fill(s, x1, y1, z1, w1, x2, y2, z2, w2, block):

        for x in range(x2 - x1 + 1):
            for y in range(y2 - y1 + 1):
                for z in range(z2 - z1 + 1):
                    for w in range(w2 - w1 + 1):

                        s.setBlock(x1 + x, y1 + y, z1 + z, w1 + w, block)

    def fillR(s, x, y, z, w, lx, ly, lz, lw, block):

        s.fill(x, y, z, w, x+lx-1, y+ly-1, z+lz-1, w+lw-1, block)

    def save(s, path):

        chunks = {}

        for coord in s.data:

            chunkCoords = (
                coord[0]//chunkSize,
                coord[2]//chunkSize,
                coord[3]//chunkSize
            )
            
            chunkStr = f"x{chunkCoords[0]}z{chunkCoords[1]}w{chunkCoords[2]}"

            if not (chunkStr in chunks):

                chunks[chunkStr] = editableChunk()

                chunkDir = f"{path}/chunks/{chunkStr}"
                
                if not os.path.isdir(chunkDir):

                    os.mkdir(chunkDir)
                    with open(f"{chunkDir}/entities.json", "w") as file:
                        file.write("[]")

            chunks[chunkStr].setBlock(
                coord[0] % chunkSize,
                coord[1],
                coord[2] % chunkSize,
                coord[3] % chunkSize,
                s.data[coord]
            )

        for chunk in chunks:

            binPath = f"{path}/chunks/{chunk}/blocks.bin"
            
            with open(binPath, "wb") as file:

                file.write(chunks[chunk].toBin())
