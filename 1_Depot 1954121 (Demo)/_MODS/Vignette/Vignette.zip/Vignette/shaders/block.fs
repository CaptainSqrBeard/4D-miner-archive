#version 330 core

// Interpolated values from the vertex shaders
in vec3 fsColor;
in vec4 fsClip;
// Ouput data
out vec4 color;

// Values that stay constant for the whole mesh.
uniform sampler2D texSampler;
uniform uvec2 texSize;

void main()
{
	// Output color = color of the texture at the specified UV
	vec2 uv = fsClip.xy / fsClip.w;
	vec2 uv2 = uv*.5+.5;

	uv2 *=  1.0 - uv2.yx;
    
    float vig = uv2.x*uv2.y * 15.0; 
    
    vig = pow(vig, 0.25);

	vec4 dsaf = texture(texSampler, vec2(fsColor.x, fsColor.y + (floor(fsColor.z) / texSize.y)));
	color = vec4(dsaf.rgb * vig, dsaf.w);
	//color = vec4(1, 1, 1, 1);
}