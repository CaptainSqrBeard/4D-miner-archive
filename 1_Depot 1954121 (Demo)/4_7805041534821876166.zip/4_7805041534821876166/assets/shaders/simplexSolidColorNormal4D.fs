#version 330 core

in float fsLighting;

uniform vec3 inColor;

// Ouput data
out vec4 color;

void main()
{
	color = vec4(inColor * (fsLighting / 4 + 0.75), 1);
}