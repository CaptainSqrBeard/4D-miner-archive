#version 330 core

// Interpolated values from the vertex shaders
in vec3 fsColor;
in float fsLighting;

// Ouput data
out vec4 color;

void main()
{
	color = vec4(fsColor * (fsLighting / 4 + 0.75), 1);
}