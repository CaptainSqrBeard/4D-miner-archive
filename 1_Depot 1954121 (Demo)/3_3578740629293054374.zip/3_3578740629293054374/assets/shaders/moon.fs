#version 330 core

// Interpolated values from the vertex shaders
in vec3 fsColor;

// Ouput data
out vec4 color;

// Values that stay constant for the whole mesh.
uniform sampler2D moonTexture;
// 1.0 = day, 0.0 = night, 0.5 = twilight?
uniform float blend;

void main()
{
	// Output color = color of the texture at the specified UV
	vec4 colorFilter = blend * vec4(1.0, 1.0, 1.0, 0.5) + (1.0 - blend) * vec4(1.0, 1.0, 1.0, 1.0);
	color = texture(moonTexture, fsColor.xy) * colorFilter;
}