#version 330 core

// Interpolated values from the vertex shaders
in vec3 fsColor;

// Ouput data
out vec4 color;

// Values that stay constant for the whole mesh.
uniform sampler2D texSampler;
uniform uvec2 texSize;

uniform int offset;

void main()
{
	// Output color = color of the texture at the specified UV
	float xCoord = fsColor.x + (1.0f / texSize.x) * offset;
	color = texture(texSampler, vec2(xCoord, fsColor.y + (floor(fsColor.z) / texSize.y)));
	//color = vec4(0, 0, 0, 1);
}