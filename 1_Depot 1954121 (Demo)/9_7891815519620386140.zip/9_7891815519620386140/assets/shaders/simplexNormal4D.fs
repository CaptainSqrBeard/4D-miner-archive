#version 330 core

// Interpolated values from the vertex shaders
in vec3 fsColor;
in float fsLighting;

// Ouput data
out vec4 color;

// Values that stay constant for the whole mesh.
uniform sampler2D texSampler;

void main()
{
	color = vec4(texture(texSampler, fsColor.xy).rgb * (fsLighting / 4 + 0.75), 1);
}