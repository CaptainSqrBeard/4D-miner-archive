#version 330 core

// Ouput data
out vec4 color;

uniform vec4 cloudColor;

void main()
{
	color = cloudColor;
}