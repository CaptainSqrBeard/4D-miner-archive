#version 330 core

// Interpolated values from the vertex shaders
in vec3 fsColor;

// Ouput data
out vec4 color;

// Values that stay constant for the whole mesh.
uniform sampler2D cloudTexture;
// 1.0 = day, 0.0 = night, 0.5 = twilight?
uniform float blend;

void main()
{
	// Output color = color of the texture at the specified UV
	float twilightDist = abs(0.5 - blend);
	float maxDist = 0.3;
	if (twilightDist > maxDist)
	{
		twilightDist = 1.0;
	}
	else
	{
		twilightDist /= maxDist;
	}
	vec4 blendColor;
	if (blend > 0.5)
	{
		blendColor = vec4(1.0, 1.0, 1.0, 1.0);
	}
	else
	{
		blendColor = vec4(0.7, 0.7, 1.0, 1.0);
	}
	vec4 colorFilter = twilightDist * blendColor + (1.0 - twilightDist) * vec4(1.0, 0.7, 0.9, 1.0);
	color = texture(cloudTexture, fsColor.xy) * colorFilter;
}