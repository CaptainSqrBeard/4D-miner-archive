#version 330 core

// Ouput data
out vec4 color;

// Values that stay constant for the whole mesh.
uniform vec3 inColor;

void main()
{
	color = vec4(inColor, 1.0);
}